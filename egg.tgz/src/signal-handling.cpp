// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("signal handling\n", stdout);
  return lionss_run_workload("signal-handling");
}
