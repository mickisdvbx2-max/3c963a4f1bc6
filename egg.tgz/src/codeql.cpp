// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("codeql"); }
int main(){
  announce();
  return lionss_run_workload("codeql");
}
